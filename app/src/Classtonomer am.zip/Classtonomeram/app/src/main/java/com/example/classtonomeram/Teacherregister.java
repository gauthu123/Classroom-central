package com.example.classtonomeram;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Teacherregister extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private Button register2;
    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacherregister);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        register2=findViewById(R.id.register2);
        auth=FirebaseAuth.getInstance();
        register2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email1=email.getText().toString();
                String password1=password.getText().toString();
                if(TextUtils.isEmpty(email1)|| TextUtils.isEmpty(password1))
                {
                    Toast.makeText(Teacherregister.this, "enter email and password both", Toast.LENGTH_SHORT).show();

                }
                else {
                    regis(email1,password1);
                }
            }
        });

    }
    private void regis(String email,String password)
    {
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(Teacherregister.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Teacherregister.this, "succesfully Registered", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Teacherregister.this, "failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}